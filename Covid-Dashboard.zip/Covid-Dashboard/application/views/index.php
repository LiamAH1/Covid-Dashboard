<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="description" content="An information dashboard for statistics on the COVID-19 pandemic.">
  <meta name="author" content="Team COVID-20">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>COVID-19 Dashboard</title>
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" rel="preload" type="text/css" href="https://bootswatch.com/4/cerulean/bootstrap.min.css"></link>

		<!-- Ubuntu font -->
		<link rel="stylesheet" rel="preload" type="text/css" href="//fonts.googleapis.com/css?family=Ubuntu"></link>

		<!--Custom CSS with random integer to stop CSS caching -->
		<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>public/custom.css?ver=<?php echo rand(111, 999) ?>"></link>
</head>

<body>

	<nav class="navbar navbar-dark bg-primary">
		<div class="container-fluid">

			<a class="navbar-brand" href="<?php echo base_url(); ?>">
				<img src="https://upload.wikimedia.org/wikipedia/commons/2/2c/Noun_Project_Health_icon_1236335.svg" class="img-responsive margin" style="display:inline" alt="Icon" width="30" height="30">
				<ul class="nav navbar-brand navbar-left">
					<li>COVID-19 Dashboard</li>
				</ul>
			</a>


				<a class="nav-link" href="#england">England</a>
				<a class="nav-link" href="#wales">Wales</a>
				<a class="nav-link" href="#scotland">Scotland</a>
				<a class="nav-link" href="#ireland">Northern Ireland</a>


			<div class="navbar-header">
				<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#myNavbar">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse mr-auto w-100 justify-content-end" id="myNavbar">
					<ul class="nav navbar-nav mr-auto">
						<li class="nav-item">
							<a class="nav-link" href="<?php echo site_url("Login/login"); ?>">Login</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#">Sign out</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</nav>

	<div class="jumbotron">
		<div class="container text-center">
			<p class="display-4">Coronavirus (COVID-19) Summary</p>
			<h3>This imformation dashboard displays data using the Government's COVID-19 API. It works by parsing JSON from an API endpoint and creates charts from the JSON Objects grabbed using Google Charts.</h3>
			<h5> Copyright © 2020, Public Health England. </h5>
		</div>
	</div>

	<div class="container-xl">
		<h1 id="england"> England <img src="https://lipis.github.io/flag-icon-css/flags/4x3/gb-eng.svg" class="img-responsive img-thumbnail margin" style="display:inline" alt="Icon" width="45" height="23"></h1>
		<div class="row">
			<div class="col-md-4">
				<h2>People tested positive</h2>
				<div id="casesChart"></div>
				<p><a id="dailyCasesButton" class="btn btn-secondary" role="button">View daily positive cases</a></p>
			</div><br>
			<div class="col-md-4" style="padding-left: 13%;">
				<h2>Deaths</h2>
				<div id="deathChart"></div>
				<p><a id="dailyDeathsButton" class="btn btn-secondary" role="button">View daily deaths</a></p>
			</div>
		</div>

		<div class="row">
			<div class="col-md-4">
				<h2>Hospital admittance</h2>
				<div id="hospitalChart"></div>
				<p><a id="dailyHospitalButton" class="btn btn-secondary" role="button">View daily hospital admittance</a></p>
			</div><br>
			<div class="col-md-4" style="padding-left: 13%;">
				<h2>Vaccinations</h2>
				<div id="vaccineChart"></div>
				<p><a id="dailyVaccineButton" class="btn btn-secondary" role="button">View daily vaccinations</a></p>
			</div>

		</div>

		<hr>

			<h1 id="wales"> Wales <img src="https://lipis.github.io/flag-icon-css/flags/4x3/gb-wls.svg" class="img-responsive img-thumbnail margin" style="display:inline" alt="Icon" width="45" height="23"></h1>
			<div class="row">
				<div class="col-md-4">
					<h2>People tested positive</h2>
					<div id="casesChartWales"></div>
					<p><a id="dailyCasesButtonWales" class="btn btn-secondary" role="button">View daily positive cases</a></p>
				</div><br>
				<div class="col-md-4" style="padding-left: 13%;">
					<h2>Deaths</h2>
					<div id="deathChartWales"></div>
					<p><a id="dailyDeathsButtonWales" class="btn btn-secondary" role="button">View daily deaths</a></p>
				</div>
			</div>

			<div class="row">
				<div class="col-md-4">
					<h2>Hospital admittance</h2>
					<div id="hospitalChartWales"></div>
					<p><a id="dailyHospitalButtonWales" class="btn btn-secondary" role="button">View daily hospital admittance</a></p>
				</div><br>
				<div class="col-md-4" style="padding-left: 13%;">
					<h2>Vaccinations</h2>
					<div id="vaccineChartWales"></div>
					<p><a id="dailyVaccineButtonWales" class="btn btn-secondary" role="button">View daily vaccinations</a></p>
				</div>

			</div>

			<hr>

				<h1 id="scotland"> Scotland <img src="https://lipis.github.io/flag-icon-css/flags/4x3/gb-sct.svg" class="img-responsive img-thumbnail margin" style="display:inline" alt="Icon" width="45" height="23"></h1>
				<div class="row">
					<div class="col-md-4">
						<h2>People tested positive</h2>
						<div id="casesChartScotland"></div>
						<p><a id="dailyCasesButtonScotland" class="btn btn-secondary" role="button">View daily positive cases</a></p>
					</div><br>
					<div class="col-md-4" style="padding-left: 13%;">
						<h2>Deaths</h2>
						<div id="deathChartScotland"></div>
						<p><a id="dailyDeathsButtonScotland" class="btn btn-secondary" role="button">View daily deaths</a></p>
					</div>
				</div>

				<div class="row">
					<div class="col-md-4">
						<h2>Hospital admittance</h2>
						<div id="hospitalChartScotland"></div>
						<p><a id="dailyHospitalButtonScotland" class="btn btn-secondary" role="button">View daily hospital admittance</a></p>
					</div><br>
					<div class="col-md-4" style="padding-left: 13%;">
						<h2>Vaccinations</h2>
						<div id="vaccineChartScotland"></div>
						<p><a id="dailyVaccineButtonScotland" class="btn btn-secondary" role="button">View daily vaccinations</a></p>
					</div>

				</div>

				<hr>

					<h1 id="ireland"> Northern Ireland <img src="https://lipis.github.io/flag-icon-css/flags/4x3/ie.svg" class="img-responsive img-thumbnail margin" style="display:inline" alt="Icon" width="45" height="23"></h1>
					<div class="row">
						<div class="col-md-4">
							<h2>People tested positive</h2>
							<div id="casesChartIreland"></div>
							<p><a id="dailyCasesButtonIreland" class="btn btn-secondary" role="button">View daily positive cases</a></p>
						</div><br>
						<div class="col-md-4" style="padding-left: 13%;">
							<h2>Deaths</h2>
							<div id="deathChartIreland"></div>
							<p><a id="dailyDeathsButtonIreland" class="btn btn-secondary" role="button">View daily deaths</a></p>
						</div>
					</div>

					<div class="row">
						<div class="col-md-4">
							<h2>Hospital admittance</h2>
							<div id="hospitalChartIreland"></div>
							<p><a id="dailyHospitalButtonIreland" class="btn btn-secondary" role="button">View daily hospital admittance</a></p>
						</div><br>
						<div class="col-md-4" style="padding-left: 13%;">
							<h2>Vaccinations</h2>
							<div id="vaccineChartIreland"></div>
							<p><a id="dailyVaccineButtonIreland" class="btn btn-secondary" role="button">View daily vaccinations</a></p>
						</div>

					</div>

		<hr>

		<h2>Cases in your Postcode</h2>
		<div class="map-responsive">
			<p>Search for cases by your postcode below</p>
			<input type="text" id="mapsearch" class="form-control w-25" size="10">
			<button type="submit" class="btn btn-secondary">Search</button>
			<br>
			<br>
			<style>
				#map {
					height: 400px;
					width: 100%;
				}
			</style>
			<script>

				let map;

				function initMap() {
					map = new google.maps.Map(document.getElementById("map"), {
						center: {
							lat: 53.4808,
							lng: 2.2426
						},
						zoom: 5,
						disableDefaultUI: true,
					});
				};

			</script>
			<div id="map"></div>
			<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB7WSOjeEdrpT0FepdCbDD376rMDgJySk4&callback=initMap&libraries=places" async></script>
		</div>
	</div>
		<button onclick="topFunction()"  class="btn btn-primary scroll-top" id="topButton">Go to top</button>
</body>

<footer>

	<div class="credit">
		<a>Professional Development Project by Muneeb Khalid, Miles Binding, Liam Hensberg, Habib Waheed and Ieman Mehmood</a>
		<br>
		<a href="https://commons.wikimedia.org/wiki/File:Noun_Project_Health_icon_1236335.svg">Noun Project Health Icon by Lakshisha</a>, <a href="https://creativecommons.org/licenses/by/3.0">CC BY 3.0</a>, via Wikimedia Commons
		<br>
		<a href="https://flagicons.lipis.dev/">flag-icons</a> via Lipis Github. © 2021 flag-icons
	</div>

	<!--Google Charts API Loader and Custom Chart Draw JS-->
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script src="<?php echo base_url(); ?>public/englandCharts.js" ?></script>
	<script src="<?php echo base_url(); ?>public/walesCharts.js" ?></script>
	<script src="<?php echo base_url(); ?>public/scotlandCharts.js" ?></script>
	<script src="<?php echo base_url(); ?>public/irelandCharts.js" ?></script>

	<!-- JQuery Slim -->
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>

	<!-- Popper JS -->
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>

	<!-- Bootstrap 4 -->
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

	<!-- AJAX JQuery -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

	<!-- Moment JS for Time formatting -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js" integrity="sha512-qTXRIMyZIFb8iQcfjXWCO8+M5Tbc38Qi5WzdPOYZHIlZpzBHG3L3by84BBBOiRGiEb7KKtAOAs5qYdUiZiQNNQ==" crossorigin="anonymous"></script>

	<!-- Custom JS & JQuery -->
	<script src="<?php echo base_url(); ?>public/custom.js" ?></script>
	<script src="<?php echo base_url(); ?>public/englandButton.js" ?></script>
	<script src="<?php echo base_url(); ?>public/walesButton.js" ?></script>
	<script src="<?php echo base_url(); ?>public/scotlandButton.js" ?></script>
	<script src="<?php echo base_url(); ?>public/irelandButton.js" ?></script>

</footer>
</html>
