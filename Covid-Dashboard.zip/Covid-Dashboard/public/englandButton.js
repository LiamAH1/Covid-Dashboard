//DAILY ENGLAND CASES SECTION
var json_data = $.ajax({
	url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaName=england&structure={%22date%22:%22date%22,%22newCases%22:%22newCasesByPublishDate%22}",
	dataType: "text",
	async: false,
}).responseText;

var parsedJSON = JSON.parse(json_data);
var dailyCases = parsedJSON.data[0].newCases;
var date = parsedJSON.data[0].date;

$(function() {
	$("#dailyCasesButton").click(function(e) {
		if (
			$("#dailyCasesNumber").length == false &&
			$("#dailyDate").length == false
		) {
			// if dailyCasesNumber div isn't created...

			$("#dailyCasesButton").after("<div id='dailyDate'></div>"); //create div with that id

			$("#dailyCasesButton").after(
				"<br></br><div id='dailyCasesNumber'></div>"
			); //create a div with that id
		}

		if ($("#dailyCasesNumber").length == true) {
			//if dailyCasesNumber does exist...

			$("#dailyCasesNumber")
				.append("#dailyCasesNumber")
				.html("Number of cases: " + dailyCases)
				.slideToggle(); //append the daily cases value from the API JSON
		}

		if ($("#dailyDate").length == true) {
			$("#dailyDate")
				.append("#dailyDate")
				.html(
					"Last Updated: " + moment(new Date(date)).format("dddd Do MMMM YYYY")
				) //append the date from the API JSON
				.slideToggle();
		}
	});
});

//DAILY ENGLAND DEATHS SECTION

var deathJSON = $.ajax({
	url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaName=england&structure={%22date%22:%22date%22,%22newDeaths%22:%22newDeathsByDeathDate%22}",
	dataType: "json",
	async: false,
}).responseText;

var parsedDeathJSON = JSON.parse(deathJSON);
var dailyDeaths = parsedDeathJSON.data[0].newDeaths;
var dateDeaths = parsedDeathJSON.data[0].date;

$(function() {
	$("#dailyDeathsButton").click(function(eDeaths) {
		if (
			$("#dailyDeathsNumber").length == false &&
			$("#dailyDateDeaths").length == false
		) {
			// if dailyDeathsNumber div isn't created...

			$("#dailyDeathsButton").after("<div id='dailyDateDeaths'></div>"); //create div with that id

			$("#dailyDeathsButton").after(
				"<br></br><div id='dailyDeathsNumber'></div>"
			); //create a div with that id
		}

		if ($("#dailyDeathsNumber").length == true) {
			//if dailyDeathsNumber does exist...

			$("#dailyDeathsNumber")
				.append("#dailyDeathsNumber")
				.html("Number of deaths: " + dailyDeaths)
				.slideToggle(); //append the daily deaths value from the API JSON
		}

		if ($("#dailyDateDeaths").length == true) {
			//if dailyDate div does NOT exist...

			$("#dailyDateDeaths")
				.append("#dailyDateDeaths")
				.html(
					"Last Updated: " +
					moment(new Date(dateDeaths)).format("dddd Do MMMM YYYY")
				)
				.slideToggle(); //append the date from the API JSON
		}
	});
});

//DAILY ENGLAND HOSTPITAL SECTION

var hospitalJSON = $.ajax({
	url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaName=england&structure={%22date%22:%22date%22,%22newAdmissions%22:%22hospitalCases%22}",
	dataType: "json",
	async: false,
}).responseText;

var parsedHospitalJSON = JSON.parse(hospitalJSON);
var dailyHospital = parsedHospitalJSON.data[0].newAdmissions;
var dateHospital = parsedHospitalJSON.data[0].date;

$(function() {
	$("#dailyHospitalButton").click(function(eHospital) {
		if (
			$("#dailyHospitalNumber").length == false &&
			$("#dailyDateHospital").length == false
		) {
			// if dailyHospitalNumber div isn't created...

			$("#dailyHospitalButton").after("<div id='dailyDateHospital'></div>"); //create div with that id

			$("#dailyHospitalButton").after(
				"<br></br><div id='dailyHospitalNumber'></div>"
			); //create a div with that id
		}

		if ($("#dailyHospitalNumber").length == true) {
			//if dailyHospitalNumber does exist...

			$("#dailyHospitalNumber")
				.append("#dailyHospitalNumber")
				.html("Number of hospital admissions: " + dailyHospital)
				.slideToggle(); //append the daily admissions value from the API JSON
		}

		if ($("#dailyDateHospital").length == true) {
			//if dailyDate div does NOT exist...

			$("#dailyDateHospital")
				.append("#dailyDateHospital")
				.html(
					"Last Updated: " +
					moment(new Date(dateHospital)).format("dddd Do MMMM YYYY")
				)
				.slideToggle(); //append the date from the API JSON
		}
	});
});

//DAILY ENGLAND VACCINATIONS SECTION

var vaccineJSON = $.ajax({
	url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaName=england&structure={%22date%22:%22date%22,%22newVaccinations%22:%22newVaccinesGivenByPublishDate%22}",
	dataType: "json",
	async: false,
}).responseText;

var parsedVaccineJSON = JSON.parse(vaccineJSON);
var dailyVaccine = parsedVaccineJSON.data[0].newVaccinations;
var dateVaccine = parsedVaccineJSON.data[0].date;

$(function() {
	$("#dailyVaccineButton").click(function(eVaccine) {
		if (
			$("#dailyVaccineNumber").length == false &&
			$("#dailyDateVaccine").length == false
		) {
			// if dailyVaccineNumber div isn't created...

			$("#dailyVaccineButton").after("<div id='dailyDateVaccine'></div>"); //create div with that id

			$("#dailyVaccineButton").after(
				"<br></br><div id='dailyVaccineNumber'></div>"
			); //create a div with that id
		}

		if ($("#dailyVaccineNumber").length == true) {
			//if dailyDeathsNumber does exist...

			$("#dailyVaccineNumber")
				.append("#dailyVaccineNumber")
				.html("Number of people vaccinated: " + dailyVaccine)
				.slideToggle(); //append the daily vaccination value from the API JSON
		}

		if ($("#dailyDateVaccine").length == true) {
			//if dailyDate div does NOT exist...

			$("#dailyDateVaccine")
				.append("#dailyDateVaccine")
				.html(
					"Last Updated: " +
					moment(new Date(dateVaccine)).format("dddd Do MMMM YYYY")
				).slideToggle(); //append the date from the API JSON
		}
	});
});
