//DAILY WALES CASES SECTION
var json_dataWales = $.ajax({
	url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaName=wales&structure={%22date%22:%22date%22,%22newCases%22:%22newCasesByPublishDate%22}",
	dataType: "json",
	async: false,
}).responseText;

var parsedJSONWales = JSON.parse(json_dataWales);
var dailyCasesWales = parsedJSONWales.data[0].newCases;
var dateWales = parsedJSONWales.data[0].date;

$(function() {
	$("#dailyCasesButtonWales").click(function(eWales) {
		if (
			$("#dailyCasesNumberWales").length == false &&
			$("#dailyDateWales").length == false
		) {
			// if dailyCasesNumber div isn't created...

			$("#dailyCasesButtonWales").after("<div id='dailyDateWales'></div>"); //create div with that id

			$("#dailyCasesButtonWales").after(
				"<br></br><div id='dailyCasesNumberWales'></div>"
			); //create a div with that id
		}

		if ($("#dailyCasesNumberWales").length == true) {
			//if dailyCasesNumber does exist...

			$("#dailyCasesNumberWales")
				.append("#dailyCasesNumberWales")
				.html("Number of cases: " + dailyCasesWales)
				.slideToggle(); //append the daily cases value from the API JSON
		}

		if ($("#dailyDateWales").length == true) {
			$("#dailyDateWales")
				.append("#dailyDateWales")
				.html(
					"Last Updated: " + moment(new Date(dateWales)).format("dddd Do MMMM YYYY")
				) //append the date from the API JSON
				.slideToggle();
		}
	});
});

//DAILY WALES DEATHS SECTION

var deathJSONWales = $.ajax({
	url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaName=wales&structure={%22date%22:%22date%22,%22newDeaths%22:%22newDeathsByPublishDate%22}",
	dataType: "json",
	async: false,
}).responseText;

var parsedDeathJSONWales = JSON.parse(deathJSONWales);
var dailyDeathsWales = parsedDeathJSONWales.data[0].newDeaths;
var dateDeathsWales = parsedDeathJSONWales.data[0].date;

$(function() {
	$("#dailyDeathsButtonWales").click(function(eDeathsWales) {
		if (
			$("#dailyDeathsNumberWales").length == false &&
			$("#dailyDateDeathsWales").length == false
		) {
			// if dailyDeathsNumber div isn't created...

			$("#dailyDeathsButtonWales").after("<div id='dailyDateDeathsWales'></div>"); //create div with that id

			$("#dailyDeathsButtonWales").after(
				"<br></br><div id='dailyDeathsNumberWales'></div>"
			); //create a div with that id
		}

		if ($("#dailyDeathsNumberWales").length == true) {
			//if dailyDeathsNumber does exist...

			$("#dailyDeathsNumberWales")
				.append("#dailyDeathsNumberWales")
				.html("Number of deaths: " + dailyDeathsWales)
				.slideToggle(); //append the daily deaths value from the API JSON
		}

		if ($("#dailyDateDeathsWales").length == true) {
			//if dailyDate div does NOT exist...

			$("#dailyDateDeathsWales")
				.append("#dailyDateDeathsWales")
				.html(
					"Last Updated: " +
					moment(new Date(dateDeathsWales)).format("dddd Do MMMM YYYY")
				)
				.slideToggle(); //append the date from the API JSON
		}
	});
});

//DAILY WALES HOSTPITAL SECTION

var hospitalJSONWales = $.ajax({
	url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaName=wales&structure={%22date%22:%22date%22,%22newAdmissions%22:%22hospitalCases%22}",
	dataType: "json",
	async: false,
}).responseText;

var parsedHospitalJSONWales = JSON.parse(hospitalJSONWales);
var dailyHospitalWales = parsedHospitalJSONWales.data[0].newAdmissions;
var dateHospitalWales = parsedHospitalJSONWales.data[0].date;

$(function() {
	$("#dailyHospitalButtonWales").click(function(eHospitalWales) {
		if (
			$("#dailyHospitalNumberWales").length == false &&
			$("#dailyDateHospitalWales").length == false
		) {
			// if dailyHospitalNumber div isn't created...

			$("#dailyHospitalButtonWales").after("<div id='dailyDateHospitalWales'></div>"); //create div with that id

			$("#dailyHospitalButtonWales").after(
				"<br></br><div id='dailyHospitalNumberWales'></div>"
			); //create a div with that id
		}

		if ($("#dailyHospitalNumberWales").length == true) {
			//if dailyHospitalNumber does exist...

			$("#dailyHospitalNumberWales")
				.append("#dailyHospitalNumberWales")
				.html("Number of hospital admissions: " + dailyHospitalWales)
				.slideToggle(); //append the daily admissions value from the API JSON
		}

		if ($("#dailyDateHospitalWales").length == true) {
			//if dailyDate div does NOT exist...

			$("#dailyDateHospitalWales")
				.append("#dailyDateHospitalWales")
				.html(
					"Last Updated: " +
					moment(new Date(dateHospitalWales)).format("dddd Do MMMM YYYY")
				)
				.slideToggle(); //append the date from the API JSON
		}
	});
});

//DAILY WALES VACCINATIONS SECTION

var vaccineJSONWales = $.ajax({
	url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaName=wales&structure={%22date%22:%22date%22,%22newVaccinations%22:%22newVaccinesGivenByPublishDate%22}",
	dataType: "json",
	async: false,
}).responseText;

var parsedVaccineJSONWales = JSON.parse(vaccineJSONWales);
var dailyVaccineWales = parsedVaccineJSONWales.data[0].newVaccinations;
var dateVaccineWales = parsedVaccineJSONWales.data[0].date;

$(function() {
	$("#dailyVaccineButtonWales").click(function(eVaccineWales) {
		if (
			$("#dailyVaccineNumberWales").length == false &&
			$("#dailyDateVaccineWales").length == false
		) {
			// if dailyVaccineNumber div isn't created...

			$("#dailyVaccineButtonWales").after("<div id='dailyDateVaccineWales'></div>"); //create div with that id

			$("#dailyVaccineButtonWales").after(
				"<br></br><div id='dailyVaccineNumberWales'></div>"
			); //create a div with that id
		}

		if ($("#dailyVaccineNumberWales").length == true) {
			//if dailyDeathsNumber does exist...

			$("#dailyVaccineNumberWales")
				.append("#dailyVaccineNumberWales")
				.html("Number of people vaccinated: " + dailyVaccineWales)
				.slideToggle(); //append the daily vaccination value from the API JSON
		}

		if ($("#dailyDateVaccineWales").length == true) {
			//if dailyDate div does NOT exist...

			$("#dailyDateVaccineWales")
				.append("#dailyDateVaccineWales")
				.html(
					"Last Updated: " +
					moment(new Date(dateVaccineWales)).format("dddd Do MMMM YYYY")
				).slideToggle(); //append the date from the API JSON
		}
	});
});
