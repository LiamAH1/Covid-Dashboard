google.charts.load('current', {
	'packages': ['line']
});

google.charts.setOnLoadCallback(drawDailyChart);
google.charts.setOnLoadCallback(drawDeathChart);
google.charts.setOnLoadCallback(drawHospitalChart);
google.charts.setOnLoadCallback(drawVaccineChart);

function drawDailyChart() {
	var jsonData = $.ajax({
		url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaName=england&structure={%22date%22:%22date%22,%22newCases%22:%22newCasesByPublishDate%22}",
		dataType: "json",
		async: false,
	}).responseText;

	var parsedJSON = JSON.parse(jsonData);

	var chartData = new google.visualization.DataTable();
	chartData.addColumn('string', 'Date');
	chartData.addColumn('number', 'New Cases');
	parsedJSON.data.reverse().forEach((element) => {
		chartData.addRow([element.date, element.newCases]);
	});

	var options = {
		chart: {
			title: "Over the past year",
		},
		width: 500,
		height: 500,
		colors: ['black']
	};

	var chart = new google.charts.Line(document.getElementById("casesChart"));

	chart.draw(chartData, google.charts.Line.convertOptions(options));
}

function drawDeathChart() {
	var jsonData = $.ajax({
		url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaName=england&structure={%22date%22:%22date%22,%22newDeaths%22:%22newDeathsByDeathDate%22}",
		dataType: "json",
		async: false,
	}).responseText;

	var parsedJSON = JSON.parse(jsonData);

	var chartData = new google.visualization.DataTable();
	chartData.addColumn('string', 'Date');
	chartData.addColumn('number', 'New Deaths');
	parsedJSON.data.reverse().forEach((element) => {
		chartData.addRow([element.date, element.newDeaths]);
	});

	var options = {
		chart: {
			title: "Over the past year",
		},
		width: 500,
		height: 500,
		colors: ['red']
	};

	var chart = new google.charts.Line(document.getElementById("deathChart"));

	chart.draw(chartData, google.charts.Line.convertOptions(options));
}

function drawHospitalChart() {
	var jsonData = $.ajax({
		url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaName=england&structure={%22date%22:%22date%22,%22newAdmissions%22:%22hospitalCases%22}",
		dataType: "json",
		async: false,
	}).responseText;

	var parsedJSON = JSON.parse(jsonData);

	var chartData = new google.visualization.DataTable();
	chartData.addColumn('string', 'Date');
	chartData.addColumn('number', 'New Admissions');
	parsedJSON.data.reverse().forEach((element) => {
		chartData.addRow([element.date, element.newAdmissions]);
	});

	var options = {
		chart: {
			title: "Over the past year",
		},
		width: 500,
		height: 500,
	};

	var chart = new google.charts.Line(document.getElementById("hospitalChart"));

	chart.draw(chartData, google.charts.Line.convertOptions(options));
}



function drawVaccineChart() {
	var jsonData = $.ajax({
		url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaName=england&structure={%22date%22:%22date%22,%22newVaccinations%22:%22newVaccinesGivenByPublishDate%22}",
		dataType: "json",
		async: false,
	}).responseText;

	var parsedJSON = JSON.parse(jsonData);

	var chartData = new google.visualization.DataTable();
	chartData.addColumn('string', 'Date');
	chartData.addColumn('number', 'New Vaccines Given');
	parsedJSON.data.reverse().forEach((element) => {
		chartData.addRow([element.date, element.newVaccinations]);
	});

	var options = {
		chart: {
			title: "Since the start of the year",
		},
		width: 500,
		height: 500,
		colors: ['green']
	};

	var chart = new google.charts.Line(document.getElementById("vaccineChart"));

	chart.draw(chartData, google.charts.Line.convertOptions(options));
}
