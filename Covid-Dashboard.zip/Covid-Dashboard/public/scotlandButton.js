//DAILY SCOTLAND CASES SECTION
var json_dataScotland = $.ajax({
	url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaName=scotland&structure={%22date%22:%22date%22,%22newCases%22:%22newCasesByPublishDate%22}",
	dataType: "text",
	async: false,
}).responseText;

var parsedJSONScotland = JSON.parse(json_dataScotland);
var dailyCasesScotland = parsedJSONScotland.data[0].newCases;
var dateScotland = parsedJSONScotland.data[0].date;

$(function() {
	$("#dailyCasesButtonScotland").click(function(e) {
		if (
			$("#dailyCasesNumberScotland").length == false &&
			$("#dailyDateScotland").length == false
		) {
			// if dailyCasesNumber div isn't created...

			$("#dailyCasesButtonScotland").after("<div id='dailyDateScotland'></div>"); //create div with that id

			$("#dailyCasesButtonScotland").after(
				"<br></br><div id='dailyCasesNumberScotland'></div>"
			); //create a div with that id
		}

		if ($("#dailyCasesNumberScotland").length == true) {
			//if dailyCasesNumber does exist...

			$("#dailyCasesNumberScotland")
				.append("#dailyCasesNumberScotland")
				.html("Number of cases: " + dailyCasesScotland)
				.slideToggle(); //append the daily cases value from the API JSON
		}

		if ($("#dailyDateScotland").length == true) {
			$("#dailyDateScotland")
				.append("#dailyDateScotland")
				.html(
					"Last Updated: " + moment(new Date(dateScotland)).format("dddd Do MMMM YYYY")
				) //append the date from the API JSON
				.slideToggle();
		}
	});
});

//DAILY SCOTLAND DEATHS SECTION

var deathJSONScotland = $.ajax({
	url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaName=scotland&structure={%22date%22:%22date%22,%22newDeaths%22:%22newDeathsByPublishDate%22}",
	dataType: "json",
	async: false,
}).responseText;

var parsedDeathJSONScotland = JSON.parse(deathJSONScotland);
var dailyDeathsScotland = parsedDeathJSONScotland.data[0].newDeaths;
var dateDeathsScotland = parsedDeathJSONScotland.data[0].date;

$(function() {
	$("#dailyDeathsButtonScotland").click(function(eDeathsScotland) {
		if (
			$("#dailyDeathsNumberScotland").length == false &&
			$("#dailyDateDeathsScotland").length == false
		) {
			// if dailyDeathsNumber div isn't created...

			$("#dailyDeathsButtonScotland").after("<div id='dailyDateDeathsScotland'></div>"); //create div with that id

			$("#dailyDeathsButtonScotland").after(
				"<br></br><div id='dailyDeathsNumberScotland'></div>"
			); //create a div with that id
		}

		if ($("#dailyDeathsNumberScotland").length == true) {
			//if dailyDeathsNumber does exist...

			$("#dailyDeathsNumberScotland")
				.append("#dailyDeathsNumberScotland")
				.html("Number of deaths: " + dailyDeathsScotland)
				.slideToggle(); //append the daily deaths value from the API JSON
		}

		if ($("#dailyDateDeathsScotland").length == true) {
			//if dailyDate div does NOT exist...

			$("#dailyDateDeathsScotland")
				.append("#dailyDateDeathsScotland")
				.html(
					"Last Updated: " +
					moment(new Date(dateDeathsScotland)).format("dddd Do MMMM YYYY")
				)
				.slideToggle(); //append the date from the API JSON
		}
	});
});

//DAILY SCOTLAND HOSTPITAL SECTION

var hospitalJSONScotland = $.ajax({
	url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaName=scotland&structure={%22date%22:%22date%22,%22newAdmissions%22:%22hospitalCases%22}",
	dataType: "json",
	async: false,
}).responseText;

var parsedHospitalJSONScotland = JSON.parse(hospitalJSONScotland);
var dailyHospitalScotland = parsedHospitalJSONScotland.data[0].newAdmissions;
var dateHospitalScotland = parsedHospitalJSONScotland.data[0].date;

$(function() {
	$("#dailyHospitalButtonScotland").click(function(eHospitalScotland) {
		if (
			$("#dailyHospitalNumberScotland").length == false &&
			$("#dailyDateHospitalScotland").length == false
		) {
			// if dailyHospitalNumber div isn't created...

			$("#dailyHospitalButtonScotland").after("<div id='dailyDateHospitalScotland'></div>"); //create div with that id

			$("#dailyHospitalButtonScotland").after(
				"<br></br><div id='dailyHospitalNumberScotland'></div>"
			); //create a div with that id
		}

		if ($("#dailyHospitalNumberScotland").length == true) {
			//if dailyHospitalNumber does exist...

			$("#dailyHospitalNumberScotland")
				.append("#dailyHospitalNumberScotland")
				.html("Number of hospital admissions: " + dailyHospitalScotland)
				.slideToggle(); //append the daily admissions value from the API JSON
		}

		if ($("#dailyDateHospitalScotland").length == true) {
			//if dailyDate div does NOT exist...

			$("#dailyDateHospitalScotland")
				.append("#dailyDateHospitalScotland")
				.html(
					"Last Updated: " +
					moment(new Date(dateHospitalScotland)).format("dddd Do MMMM YYYY")
				)
				.slideToggle(); //append the date from the API JSON
		}
	});
});

//DAILY SCOTLAND VACCINATIONS SECTION

var vaccineJSONScotland = $.ajax({
	url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaName=scotland&structure={%22date%22:%22date%22,%22newVaccinations%22:%22newVaccinesGivenByPublishDate%22}",
	dataType: "json",
	async: false,
}).responseText;

var parsedVaccineJSONScotland = JSON.parse(vaccineJSONScotland);
var dailyVaccineScotland = parsedVaccineJSONScotland.data[0].newVaccinations;
var dateVaccineScotland = parsedVaccineJSONScotland.data[0].date;

$(function() {
	$("#dailyVaccineButtonScotland").click(function(eVaccineScotland) {
		if (
			$("#dailyVaccineNumberScotland").length == false &&
			$("#dailyDateVaccineScotland").length == false
		) {
			// if dailyVaccineNumber div isn't created...

			$("#dailyVaccineButtonScotland").after("<div id='dailyDateVaccineScotland'></div>"); //create div with that id

			$("#dailyVaccineButtonScotland").after(
				"<br></br><div id='dailyVaccineNumberScotland'></div>"
			); //create a div with that id
		}

		if ($("#dailyVaccineNumberScotland").length == true) {
			//if dailyDeathsNumber does exist...

			$("#dailyVaccineNumberScotland")
				.append("#dailyVaccineNumberScotland")
				.html("Number of people vaccinated: " + dailyVaccineScotland)
				.slideToggle(); //append the daily vaccination value from the API JSON
		}

		if ($("#dailyDateVaccineScotland").length == true) {
			//if dailyDate div does NOT exist...

			$("#dailyDateVaccineScotland")
				.append("#dailyDateVaccineScotland")
				.html(
					"Last Updated: " +
					moment(new Date(dateVaccineScotland)).format("dddd Do MMMM YYYY")
				).slideToggle(); //append the date from the API JSON
		}
	});
});
