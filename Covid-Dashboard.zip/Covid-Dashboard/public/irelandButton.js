//DAILY Ireland CASES SECTION
var json_dataIreland = $.ajax({
	url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaCode=N92000002&structure={%22date%22:%22date%22,%22newCases%22:%22newCasesByPublishDate%22}",
	dataType: "json",
	async: false,
}).responseText;

var parsedJSONIreland = JSON.parse(json_dataIreland);
var dailyCasesIreland = parsedJSONIreland.data[0].newCases;
var dateIreland = parsedJSONIreland.data[0].date;

$(function() {
	$("#dailyCasesButtonIreland").click(function(e) {
		if (
			$("#dailyCasesNumberIreland").length == false &&
			$("#dailyDateIreland").length == false
		) {
			// if dailyCasesNumber div isn't created...

			$("#dailyCasesButtonIreland").after("<div id='dailyDateIreland'></div>"); //create div with that id

			$("#dailyCasesButtonIreland").after(
				"<br></br><div id='dailyCasesNumberIreland'></div>"
			); //create a div with that id
		}

		if ($("#dailyCasesNumberIreland").length == true) {
			//if dailyCasesNumber does exist...

			$("#dailyCasesNumberIreland")
				.append("#dailyCasesNumberIreland")
				.html("Number of cases: " + dailyCasesIreland)
				.slideToggle(); //append the daily cases value from the API JSON
		}

		if ($("#dailyDateIreland").length == true) {
			$("#dailyDateIreland")
				.append("#dailyDateIreland")
				.html(
					"Last Updated: " + moment(new Date(dateIreland)).format("dddd Do MMMM YYYY")
				) //append the date from the API JSON
				.slideToggle();
		}
	});
});

//DAILY Ireland DEATHS SECTION

var deathJSONIreland = $.ajax({
	url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaCode=N92000002&structure={%22date%22:%22date%22,%22newDeaths%22:%22newDeathsByPublishDate%22}",
	dataType: "json",
	async: false,
}).responseText;

var parsedDeathJSONIreland = JSON.parse(deathJSONIreland);
var dailyDeathsIreland = parsedDeathJSONIreland.data[0].newDeaths;
var dateDeathsIreland = parsedDeathJSONIreland.data[0].date;

$(function() {
	$("#dailyDeathsButtonIreland").click(function(eDeathsIreland) {
		if (
			$("#dailyDeathsNumberIreland").length == false &&
			$("#dailyDateDeathsIreland").length == false
		) {
			// if dailyDeathsNumber div isn't created...

			$("#dailyDeathsButtonIreland").after("<div id='dailyDateDeathsIreland'></div>"); //create div with that id

			$("#dailyDeathsButtonIreland").after(
				"<br></br><div id='dailyDeathsNumberIreland'></div>"
			); //create a div with that id
		}

		if ($("#dailyDeathsNumberIreland").length == true) {
			//if dailyDeathsNumber does exist...

			$("#dailyDeathsNumberIreland")
				.append("#dailyDeathsNumberIreland")
				.html("Number of deaths: " + dailyDeathsIreland)
				.slideToggle(); //append the daily deaths value from the API JSON
		}

		if ($("#dailyDateDeathsIreland").length == true) {
			//if dailyDate div does NOT exist...

			$("#dailyDateDeathsIreland")
				.append("#dailyDateDeathsIreland")
				.html(
					"Last Updated: " +
					moment(new Date(dateDeathsIreland)).format("dddd Do MMMM YYYY")
				)
				.slideToggle(); //append the date from the API JSON
		}
	});
});

//DAILY Ireland HOSTPITAL SECTION

var hospitalJSONIreland = $.ajax({
	url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaCode=N92000002&structure={%22date%22:%22date%22,%22newAdmissions%22:%22hospitalCases%22}",
	dataType: "json",
	async: false,
}).responseText;

var parsedHospitalJSONIreland = JSON.parse(hospitalJSONIreland);
var dailyHospitalIreland = parsedHospitalJSONIreland.data[0].newAdmissions;
var dateHospitalIreland = parsedHospitalJSONIreland.data[0].date;

$(function() {
	$("#dailyHospitalButtonIreland").click(function(eHospitalIreland) {
		if (
			$("#dailyHospitalNumberIreland").length == false &&
			$("#dailyDateHospitalIreland").length == false
		) {
			// if dailyHospitalNumber div isn't created...

			$("#dailyHospitalButtonIreland").after("<div id='dailyDateHospitalIreland'></div>"); //create div with that id

			$("#dailyHospitalButtonIreland").after(
				"<br></br><div id='dailyHospitalNumberIreland'></div>"
			); //create a div with that id
		}

		if ($("#dailyHospitalNumberIreland").length == true) {
			//if dailyHospitalNumber does exist...

			$("#dailyHospitalNumberIreland")
				.append("#dailyHospitalNumberIreland")
				.html("Number of hospital admissions: " + dailyHospitalIreland)
				.slideToggle(); //append the daily admissions value from the API JSON
		}

		if ($("#dailyDateHospitalIreland").length == true) {
			//if dailyDate div does NOT exist...

			$("#dailyDateHospitalIreland")
				.append("#dailyDateHospitalIreland")
				.html(
					"Last Updated: " +
					moment(new Date(dateHospitalIreland)).format("dddd Do MMMM YYYY")
				)
				.slideToggle(); //append the date from the API JSON
		}
	});
});

//DAILY Ireland VACCINATIONS SECTION

var vaccineJSONIreland = $.ajax({
	url: "https://api.coronavirus.data.gov.uk/v1/data?filters=areaType=nation;areaCode=N92000002&structure={%22date%22:%22date%22,%22newVaccinations%22:%22newVaccinesGivenByPublishDate%22}",
	dataType: "json",
	async: false,
}).responseText;

var parsedVaccineJSONIreland = JSON.parse(vaccineJSONIreland);
var dailyVaccineIreland = parsedVaccineJSONIreland.data[0].newVaccinations;
var dateVaccineIreland = parsedVaccineJSONIreland.data[0].date;

$(function() {
	$("#dailyVaccineButtonIreland").click(function(eVaccineIreland) {
		if (
			$("#dailyVaccineNumberIreland").length == false &&
			$("#dailyDateVaccineIreland").length == false
		) {
			// if dailyVaccineNumber div isn't created...

			$("#dailyVaccineButtonIreland").after("<div id='dailyDateVaccineIreland'></div>"); //create div with that id

			$("#dailyVaccineButtonIreland").after(
				"<br></br><div id='dailyVaccineNumberIreland'></div>"
			); //create a div with that id
		}

		if ($("#dailyVaccineNumberIreland").length == true) {
			//if dailyDeathsNumber does exist...

			$("#dailyVaccineNumberIreland")
				.append("#dailyVaccineNumberIreland")
				.html("Number of people vaccinated: " + dailyVaccineIreland)
				.slideToggle(); //append the daily vaccination value from the API JSON
		}

		if ($("#dailyDateVaccineIreland").length == true) {
			//if dailyDate div does NOT exist...

			$("#dailyDateVaccineIreland")
				.append("#dailyDateVaccineIreland")
				.html(
					"Last Updated: " +
					moment(new Date(dateVaccineIreland)).format("dddd Do MMMM YYYY")
				).slideToggle(); //append the date from the API JSON
		}
	});
});
